package com.fenix.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fenix.sales.entity.Editora;

public interface EditoraRepository extends JpaRepository<Editora, Integer>{

}
