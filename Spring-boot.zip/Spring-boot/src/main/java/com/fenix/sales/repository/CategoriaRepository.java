
package com.fenix.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fenix.sales.entity.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer>{

}
